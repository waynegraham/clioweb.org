<div id="sidebar">
    <p>Here's my sidebar</p>
</div>