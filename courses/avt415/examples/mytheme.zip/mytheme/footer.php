<div id="footer">
    <p>Here's my footer</p>
</div>
</body>
</html>