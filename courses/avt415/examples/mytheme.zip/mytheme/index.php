<!doctype HTML>
<html>
    <head>
        <meta charset="utf-8">
        <title><?php echo bloginfo('name'); ?></title>
        <link rel="stylesheet" href="<?php echo bloginfo('stylesheet_url'); ?>">
    </head>
    <body>
        <h1>
        <?php echo bloginfo('name'); ?>
        </h1>
        <p><?php echo bloginfo('description'); ?></p>
        
        <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
            
        <div class="post">
            <h2><?php echo the_title(); ?></h2>
            <p class="date"><?php echo the_date(); ?></p>
            <?php echo the_excerpt(); ?>
        </div>
        
        <?php endwhile; else: ?>
        <p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
        <?php endif; ?>
        
        
    </body>
</html>
