<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
    "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8">
    <title>index</title>
    <link rel="stylesheet" href="<?php echo bloginfo('stylesheet_url'); ?>">
</head>
<body id="index">
    <div id="header">
        <h1><?php echo bloginfo('name'); ?></h1>
        <p><?php echo bloginfo('admin_email'); ?></p>
    </div>